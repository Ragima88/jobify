import "./black-button.scss";
const BlackButton = () => {
  return <button className="black-button">Apply for job</button>;
};
export default BlackButton;
