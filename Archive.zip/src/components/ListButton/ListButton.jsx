import "./list-button.scss";

const ListButton = () => {
  return <button className="list-button">Load More Listings</button>;
};
export default ListButton;
