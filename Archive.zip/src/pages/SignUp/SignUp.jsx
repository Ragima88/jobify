import "./sign-up.scss";
const SignUp = () => {
  return <></>;
};
export default SignUp;
