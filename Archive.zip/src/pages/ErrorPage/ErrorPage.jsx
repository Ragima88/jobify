import "./error-page.scss";

const ErrorPage = () => {
  return <>Error</>;
};
export default ErrorPage;
