export const locations = [
  {
    id: 1,
    name: "New York, NY",
  },
  {
    id: 2,
    name: "Los Angeles, CA",
  },
  {
    id: 3,
    name: "Chicago, IL",
  },
  {
    id: 4,
    name: "Houston, TX",
  },
  {
    id: 5,
    name: "Phoenix, AZ",
  },
  {
    id: 6,
    name: "Philadelphia, PA",
  },
  {
    id: 7,
    name: "San Antonio, TX",
  },
  {
    id: 8,
    name: "San Diego, CA",
  },
  {
    id: 9,
    name: "Dallas, TX",
  },
  {
    id: 10,
    name: "San Jose, CA",
  },
  {
    id: 11,
    name: "Austin, TX",
  },
  {
    id: 12,
    name: "Jacksonville, FL",
  },
  {
    id: 13,
    name: "Fort Worth, TX",
  },
  {
    id: 14,
    name: "Columbus, OH",
  },
  {
    id: 15,
    name: "Charlotte, NC",
  },
  {
    id: 16,
    name: "San Francisco, CA",
  },
  {
    id: 17,
    name: "Indianapolis, IN",
  },
  {
    id: 18,
    name: "Seattle, WA",
  },
  {
    id: 19,
    name: "Denver, CO",
  },
  {
    id: 20,
    name: "Washington, DC",
  },
  {
    id: 21,
    name: "Boston, MA",
  },
  {
    id: 22,
    name: "El Paso, TX",
  },
  {
    id: 23,
    name: "Nashville, TN",
  },
  {
    id: 24,
    name: "Detroit, MI",
  },
  {
    id: 25,
    name: "Portland, OR",
  },
];
