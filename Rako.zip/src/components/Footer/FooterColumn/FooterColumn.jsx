import "./footer-column.scss";

const FooterColumn = ({ children }) => {
  return <div className={"footer-column"}>{children}</div>;
};

export default FooterColumn;
